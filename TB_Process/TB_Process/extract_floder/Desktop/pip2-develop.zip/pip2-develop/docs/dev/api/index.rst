API Reference
=============

Freeze
------

.. autofunction:: pip2.commands.freeze.freeze

Install
-------

.. autofunction:: pip2.commands.install.install

Search
------

.. autofunction:: pip2.commands.search.search

Uninstall
---------

.. autofunction:: pip2.commands.uninstall.uninstall
