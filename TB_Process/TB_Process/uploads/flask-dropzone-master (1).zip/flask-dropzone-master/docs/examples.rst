.. include:: ../examples/README.rst
