API Reference
==============

Dropzone Object in Template
----------------------------
.. module:: flask_dropzone

.. autoclass:: _Dropzone
   :members:
   :undoc-members:

Utils
-----

.. module:: flask_dropzone.utils

.. autofunction:: get_url
.. autofunction:: random_filename
